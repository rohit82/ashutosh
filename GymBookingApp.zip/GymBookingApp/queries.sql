create sequence custiseq start with 1000;
create sequence custiseq1 
create sequence custseq start with 1000;
select * from PRODUCTDETAILS