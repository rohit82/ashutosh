package com.capgemini.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.entities.Customer;
import com.capgemini.service.IBookingService;

@Controller
public class GymBookingController {

	@Autowired
	private IBookingService bookingService;
	
	
	
	public IBookingService getBookingService() {
		return bookingService;
	}
	public void setBookingService(IBookingService bookingService) {
		this.bookingService = bookingService;
	}
	public GymBookingController() {
		super();
	}
	public GymBookingController(IBookingService bookingService) {
		super();
		this.bookingService = bookingService;
	}
	@RequestMapping("AddCustomer")
	public String getAddCostomerPage(Model model)
	{
		System.out.println("start");
		List<String>gymNames=new ArrayList<>();
		gymNames.add("Gold");
		gymNames.add("hahha");
		gymNames.add("talaware");
		List<String>timings=new ArrayList<>();
		timings.add("morning");
		timings.add("Afternoon");
		timings.add("Evening");
		model.addAttribute("gymNames",gymNames);
		model.addAttribute("timings", timings);
		model.addAttribute("customer",new Customer());
		System.out.println("end");
		return"AddCustomerPage";
		
	}
	@RequestMapping(value="processAddcustomer",method=RequestMethod.POST)
	public String processAddCustomerForm(@ModelAttribute("customer")@Valid Customer customer,
			BindingResult result,Model model){
		if(result.hasErrors()){
			List<String>gymNames=new ArrayList<>();
			gymNames.add("Gold");
			gymNames.add("hahha");
			gymNames.add("talaware");
			List<String>timings=new ArrayList<>();
			timings.add("morning");
			timings.add("Afternoon");
			timings.add("Evening");
			model.addAttribute("gymNames",gymNames);
			model.addAttribute("timings", timings);
			model.addAttribute("customer", customer);
			return"AddCustomerPage";
		}
		int customerId=-1;
		try {
			System.out.println("hi");
			bookingService.addCustomer(customer);
		} catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("errMsg", "somthing went wrong while adding customer");
			return "ErrorPage";
			
		}
		model.addAttribute("message", "Customer Added sussessFully with id:"+customerId);
		
		return "SuccessPage";
	}
	@RequestMapping("ViewCustomer")
	public String getViewcustomerPage()
	{
		return"ViewCustomerPage";
	}
	
	@RequestMapping(value="processViewcustomer",method=RequestMethod.POST)
	public String processViewCustomer(@RequestParam("customerId") int id,Model model){
		Customer customer=null;
		try {
			
			customer =bookingService.getCustomer(id);
		} catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("errMsg", "somthing went wrong while adding customer");
			return "ErrorPage";
			
		}
		model.addAttribute("customer", customer);
		return "ViewCustomerPage";
	}
}
