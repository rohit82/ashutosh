package com.capgemini.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.capgemini.entities.Customer;
import com.capgemini.exception.BookingException;

@Repository
public class BookingDaoImpl implements IBookingDao {

	@PersistenceContext
	private EntityManager entityManager;

	public BookingDaoImpl(EntityManager entityManager) {
		super();
		this.entityManager = entityManager;
	}

	public BookingDaoImpl() {
		super();
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public int addCustomer(Customer customer) throws BookingException {
		int bookingId=-1;
		try {
			System.out.println("hello");
			entityManager.persist(customer);
			bookingId=customer.getId();
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new BookingException(e.getMessage());
		}
		return bookingId;
	}

	@Override
	public Customer getCustomer(int id) throws BookingException {
		Customer customer=null;
		
		try {
			customer=entityManager.find(Customer.class, id);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BookingException(e.getMessage());
		}
		if(customer==null)
			throw new BookingException("Cuatomer not found");
		
		return customer;
	}
	
	
}
