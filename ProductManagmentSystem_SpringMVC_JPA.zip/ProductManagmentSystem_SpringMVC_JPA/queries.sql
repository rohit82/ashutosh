create sequence productid_seq start with 100 increment by 1;
select * from PRODUCTDETAILS