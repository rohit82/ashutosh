package com.capgemini.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import oracle.net.aso.p;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.entities.Product;
import com.capgemini.service.IProductService;

@Controller
public class ProductController {

	@Autowired
	IProductService productService;

	public ProductController(IProductService productService) {
		super();
		this.productService = productService;
	}

	public IProductService getProductService() {
		return productService;
	}

	public void setProductService(IProductService productService) {
		this.productService = productService;
	}

	public ProductController() {
		super();
	}

	@RequestMapping("home")
	public String gethomePage(){
		
		return "HomePage";
	}
	@RequestMapping("addproduct")
	public String getAddproductPage(Model model){
		
		List<String>categories=new ArrayList<>();
		categories.add("Shoes");
		categories.add("Electronic");
		categories.add("Clothes");
		categories.add("Books");
		categories.add("homeTools");
		//add the 
		model.addAttribute("product", new Product());
		//add categories to build drop down list in addProduct dynamically
		model.addAttribute("categories", categories);
		//return view name
		return "AddProductPage";
	}
	@RequestMapping(value="ProcessaddproductForm")
	public ModelAndView processAddProduct(@ModelAttribute("product")@Valid Product product
			,BindingResult result,Model  model){
		if(result.hasErrors()==true){
			
			List<String>categories=new ArrayList<>();
			categories.add("Shoes");
			categories.add("Electronic");
			categories.add("Clothes");
			categories.add("Books");
			categories.add("homeTools");
			//add the 
			model.addAttribute("product",  product);
			//add categories to build drop down list in addProduct dynamically
			model.addAttribute("categories", categories);
			
			return new ModelAndView("AddProductPage");
		}
		int productId=-1;
		try {
			productId= productService.addProduct(product);
			model.addAttribute("message", "Product Added Successfully. With ProductId:- "+productId);
			return new ModelAndView("SuccessPage");
		} catch (Exception e) {
			model.addAttribute("errMsg","Could not add product "+e.getMessage());
			return new ModelAndView("ErrorPage");
		}
		
	}
	@RequestMapping("getproduct.do")
	public String getProductPage(){
		return "GetProductPage";
	}
	@RequestMapping("processgetproductform")
	public ModelAndView processGetProductForm(@RequestParam ("productId") int pid){
		
		Product product=null;
		try {
			product=productService.getProduct(pid);
			return new ModelAndView("GetProductPage","product",product);
			
		} catch (Exception e) {
			return new ModelAndView("ErrorPage","errMsg","Could not retrive the product. resone"+e.getMessage());
		}
	}
	@RequestMapping("viewproducts")
	public String getViewProductsPage(Model model){
		
		List<Product> products=null;
		try {
			
			products= productService.getAllProducts();
			model.addAttribute("products", products);
			
		} catch (Exception e) {
			model.addAttribute("errMsg", "Could not Display product Reason: "+e.getMessage());
			return "ErrorPage";
		}
		return"ViewAllProductPage";
		
	}
	@RequestMapping("getupdatepage")
	public String getUpdatePage(@RequestParam("pid") int id, Model model){
		
		
		List<String>categories=new ArrayList<>();
		categories.add("Shoes");
		categories.add("Electronic");
		categories.add("Clothes");
		categories.add("Books");
		categories.add("homeTools");
		Product product=null;
		
		try {
			product=productService.getProduct(id);
			
		} catch (Exception e) {
			model.addAttribute("errMsg","Could not retriivr product id Reason: "+e.getMessage());
			return "ErrorPage";
			// TODO: handle exception
		}
		//add the 
		model.addAttribute("product",  product);
		//add categories to build drop down list in addProduct dynamically
		model.addAttribute("categories", categories);
		
		return "UpdatePage";
	}
	
	@RequestMapping(value="processupdatepageform", method=RequestMethod.POST)
	public String processupdatepageform(@ModelAttribute("product")@Valid Product product,
			BindingResult res,Model model){
		    if(res.hasErrors()==true){
		    	List<String>categories=new ArrayList<>();
				categories.add("Shoes");
				categories.add("Electronic");
				categories.add("Clothes");
				categories.add("Books");
				categories.add("homeTools");
				//add the 
				model.addAttribute("product",  product);
				//add categories to build drop down list in addProduct dynamically
				model.addAttribute("categories", categories);
		       
				return "UpdatePage";
		    }
		try {
			productService.updateProduct(product);
			
			
		} catch (Exception e) {
			model.addAttribute("errMsg", "could bnot update product Details Reason: "+e.getMessage());
			return "ErrorPage";
		}
		model.addAttribute("message", "Product Updated Successfully");
		return "SuccessPage";
		
	}
}





