package com.capgemini.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.entities.Product;
import com.capgemini.exception.ProductException;



@Repository("productDAO")
public class ProductDAOImpl implements IProductDAO 
{
	@PersistenceContext
	private EntityManager entityManager ;
	
	public ProductDAOImpl() 
	{
		
	}
	@Override
	public int addProduct(Product product) throws ProductException 
	{
		int productId = 0 ;
		try 
		{
			
			
			entityManager.persist(product) ;
			
			productId = product.getId() ;
			
		} 
		catch (Exception e) 
		{
			
			
			throw new ProductException(e.getMessage());
		}
		
		return productId;
	}

	@Override
	public void updateProduct(Product product) throws ProductException 
	{
		try 
		{
		
			
			entityManager.merge(product) ;
			entityManager.flush();
			
			
		} 
		catch (Exception e) 
		{
			
			
			throw new ProductException(e.getMessage());
		}
	}

	@Override
	public Product getProduct(int id) throws ProductException 
	{
		Product product = null ;
		
		try 
		{
			
			
			product = entityManager.find(Product.class, id) ;
			
			
		} 
		catch (Exception e) 
		{
			
			
			throw new ProductException(e.getMessage());
		}
		
		if( product == null )
		{
			throw new ProductException("No Product Found with id " + id ) ;
		}
		
		return product;
	}

	@Override
	public void removeProduct(int id) throws ProductException 
	{
		try 
		{
			entityManager.getTransaction().begin() ;
			
			Product product = entityManager.find(Product.class, id) ;
			entityManager.remove(product) ;
			
			
		} 
		catch (Exception e) 
		{
			
			
			throw new ProductException(e.getMessage());
		}

	}
	@Override
	public List<Product> getAllProducts() throws ProductException {
		
		List<Product> products = null ;
		try
		{
			
			TypedQuery<Product> query = entityManager.createNamedQuery("GetAllProducts",Product.class);
			products = query.getResultList();
			
			
		}catch (Exception e) 
		{
			throw new ProductException(e.getMessage());
		}
		
		if(products == null || products.isEmpty())
		{
			throw new ProductException("No Products to display");
		}
		return products;
	}
	@Override
	public Product getProductByName(String name) throws ProductException {
		
		Product product = null ;
		try
		{
			
			String query = "select product from Product product where product.name=:pname" ;
			TypedQuery<Product> query1 = entityManager.createQuery(query, Product.class) ;
			query1.setParameter("pname", name) ;
			product = query1.getSingleResult() ;
			
		}
		catch(Exception e)
		{
			
			throw new ProductException("Something went wrong while searching by name");
		}
		return product;
	}
	@Override
	public List<Product> getProductByPrice(float min, float max)
			throws ProductException {
		List<Product> productList = null ;
		
		try
		{
			
			
			TypedQuery<Product> query = entityManager.createNamedQuery("GetProductByPrice",Product.class) ;
			query.setParameter("min", min) ;
			query.setParameter("max", max) ;
			productList = query.getResultList() ;
			
		}
		
		catch(Exception e)
		{
			throw new ProductException("Product Not FOund");
		}
		if(productList == null || productList.isEmpty())
		{
			throw new ProductException("NO Product Found ") ;
		}
		return productList;
	}

}
