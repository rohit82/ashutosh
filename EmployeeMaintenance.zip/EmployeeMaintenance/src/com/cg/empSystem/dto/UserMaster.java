package com.cg.empSystem.dto;


import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

@Entity(name="usermaster")
@Table(name="USER_MASTER")
@NamedQueries({ @NamedQuery(name = "qry" , query = "select u from usermaster u where userName is :name")
})

@SequenceGenerator(name="user_seq",sequenceName="hibernate_sequence", allocationSize=1,initialValue=100000)
public class UserMaster implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String userId;
	private String userName;
	private String userPassword;
	private String userType;
	private Employee employeeUser;

	@Id
	@GenericGenerator(name ="user_seq", strategy = "Mypackage.StringSequenceGenerator")
	@GeneratedValue(generator="user_seq",strategy=GenerationType.SEQUENCE)
	@Column(name="USERID")
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	@Column(name="USERNAME")
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	@Column(name="USERPASSWORD")
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	
	@Column(name="USERTYPE")
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}

	/*@OneToOne(mappedBy="user",cascade=CascadeType.ALL)
	public Employee getEmployeeUser() {
		return employeeUser;
	}

	public void setEmployeeUser(Employee employeeUser) {
		this.employeeUser = employeeUser;
	}*/

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "UserMaster [userId=" + userId + ", userName=" + userName
				+ ", userPassword=" + userPassword + ", userType=" + userType
				+ "]";
	}
		
}
