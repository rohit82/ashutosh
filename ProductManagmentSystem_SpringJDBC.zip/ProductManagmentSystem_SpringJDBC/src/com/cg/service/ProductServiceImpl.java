package com.cg.service;

import java.util.List;

import com.cg.dao.IProductDAO;
import com.cg.dao.ProductDAOImpl;
import com.cg.entities.Product;
import com.cg.exception.ProductException;

public class ProductServiceImpl implements IProductService {

	private IProductDAO productDao;
	public ProductServiceImpl() {
	
	}
	@Override
	public int addPrduct(Product product) throws ProductException {
		// TODO Auto-generated method stub
		return productDao.addPrduct(product);
	}

	@Override
	public void updateProduct(Product product) throws ProductException {
		productDao.updateProduct(product);

	}

	@Override
	public Product getProduct(int id) throws ProductException {
		// TODO Auto-generated method stub
		
		return productDao.getProduct(id);
	}

	@Override
	public void removeProduct(int id) throws ProductException {
		// TODO Auto-generated method stub

		productDao.removeProduct(id);
	}
	@Override
	public List<Product> getAllProduct() throws ProductException {
		// TODO Auto-generated method stub
		return productDao.getAllProduct();
	}

}
