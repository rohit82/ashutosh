package com.cg.view;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.entities.Product;
import com.cg.exception.ProductException;
import com.cg.service.IProductService;
import com.cg.service.ProductServiceImpl;

public class Menu {

	private IProductService productService;
	
	public void menu(){
	productService=new ProductServiceImpl();	
		Scanner console=new Scanner(System.in);
		
		System.out.println("1)Add product");
		System.out.println("2)Get product");
		System.out.println("3)Update product");
		System.out.println("4)Remove product");
		System.out.println("5)list product");
		System.out.println("9)exit product");
		int choice=console.nextInt();
		switch (choice) {
		case 1:
			
			System.out.println("Enter Product Nmae:");
			String name=console.next();
			System.out.println("Enter Product Quantity:");
			int qty=console.nextInt();
			System.out.println("Enter the product price:");
			float price=console.nextFloat();
			Product p1=new Product(name,qty,price);
			
			try {
				int productId=productService.addPrduct(p1);
				System.out.println("Product insert successfully id= "+productId);
				
			} catch (ProductException e) {
				System.out.println(e.getMessage());
			}
			catch(Exception e){
				System.out.println(e.getMessage());
			}
			break;
		case 2:
			System.out.println("Enter the product id to retrive Product Info");
			System.out.println("product id:");
			int productId=console.nextInt();
			
			try {
				Product p2= productService.getProduct(productId);
				System.out.println("ID:"+p2.getId());
				System.out.println("Nmae: "+p2.getName());
				System.out.println("Quantity: "+p2.getQuantity());
				System.out.println("Price: "+p2.getPrice());
				
			} catch (ProductException e) {
				System.out.println("could not find the product "+e.getMessage());
			}
			catch(Exception e){
				System.out.println(e.getMessage());
			}
			break;
			
		case 3:
			System.out.println("Enter the product id to update: ");
			int uId=console.nextInt();
			Product p3=null;

			try {
				 p3= productService.getProduct(uId);
				System.out.println("Old Product name: "+p3.getName());
				System.out.print("Update? y/n");
				char reply=console.next().toLowerCase().charAt(0);
				if(reply=='y'){
					System.out.println("enter new Nmae:");
					
					String newName=console.next();
					p3.setName(newName);
					
				}
				System.out.println("Old Product quantity: "+p3.getQuantity());
				System.out.print("Update? y/n");
				reply=console.next().toLowerCase().charAt(0);
				if(reply=='y'){
					System.out.println("enter new quantity:");
					
					int newQun=console.nextInt();
					p3.setQuantity(newQun);
						
				}
				System.out.println("Old Product price: "+p3.getPrice());
				System.out.print("Update? y/n");
				reply=console.next().toLowerCase().charAt(0);
				if(reply=='y'){
					System.out.println("enter new price:");
					
					int newPri=console.nextInt();
					p3.setPrice(newPri);
						
				}
				
			} catch (ProductException e) {
				System.out.println("could not find the product plz try again "+e.getMessage());
			}
			
			catch(Exception e){
				System.out.println(e.getMessage());
			}

			try {
				if(p3!=null)
					productService.updateProduct(p3);
				
			} catch (ProductException e) {
				System.out.println("could not update "+e.getMessage());
			}
			
			catch(Exception e){
				System.out.println(e.getMessage());
			}
			break;
		case 4:
			System.out.println("Enter product Id To remove Product");
			System.out.println("Product id:");
			int rid=console.nextInt();
			
			try {
				
				productService.removeProduct(rid);
				
			}catch (ProductException e) {
				System.out.println("could not find the product plz try again "+e.getMessage());
			}
			
			catch(Exception e){
				System.out.println(e.getMessage());
			}
			
			
			break;
		case 5:
			
			try {
				List<Product>products= productService.getAllProduct();
				Iterator<Product> it=products.iterator();
				System.out.printf("%s %6s %10s %s \n","ID" ,"Name","quantity"," Price");
				while (it.hasNext()) {
					Product product=it.next();
					System.out.printf("%d %2s %5d %f \n",product.getId(),product.getName(),product.getQuantity(),product.getPrice());
					
				}
				
			} catch (ProductException e) {
				System.out.println("could not display product "+e.getMessage());
			}
			catch (Exception e) {
				System.out.println(e.getMessage());
			}
			
		case 9:
			System.exit(0);
			break;
			
		default:
			break;
		}
	}
	
	public static void main(String[] args) {
		
		Menu appplication=new Menu();
		while(true){
			try{
				appplication.menu();
			}
			catch(Exception e){
				System.out.println("something went wrong "+e.getMessage());
			}
		}
	}
}
