package com.cg.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.cg.entities.Product;
import com.cg.exception.ProductException;

@Component("productDAO")
public class ProductDAOImpl implements IProductDAO {

	@Autowired
	private JdbcTemplate JdbcTemplate;
	public ProductDAOImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public JdbcTemplate getJdbcTemplate() {
		return JdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		JdbcTemplate = jdbcTemplate;
	}

	@Override
	public int addPrduct(Product product) throws ProductException {
		int productId =0;
		try {
			productId = JdbcTemplate.queryForObject("select hibernet_sequence.nextval from dual", Integer.class);
			String query="insert into Productdetails values(?,?,?,?)";
			Object[] params=new Object[]{productId,product.getName(),product.getQuantity(),product.getPrice()};
			JdbcTemplate.update(query,params);
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			throw new ProductException(e.getMessage());
		}

		return productId;
	}

	@Override
	public void updateProduct(Product product) throws ProductException {

		try {

			String query="update Productdetails set pname=?,pquantity,price=? where pid=?";
			Object[] params=new Object[]{product,product.getName(),product.getQuantity(),product.getPrice(),product.getId()};
			JdbcTemplate.update(query,params);
		} catch (DataAccessException e) {
			throw new ProductException(e.getMessage());

		}


	}

	@Override
	public Product getProduct(int id) throws ProductException {
		Product product=null;
		try {
			String query="select * from Productdetails where pid=?";
			product=(Product)JdbcTemplate.queryForObject(query, new ProductMapper());
		} catch (Exception e) {
			throw new ProductException(e.getMessage());

		}
		if(product==null)
			throw new ProductException("no product found "+id);
		return product;
	}

	@Override
	public void removeProduct(int id) throws ProductException {
		String query="delete from Productdetails where pid =?";
		JdbcTemplate.update(query,id);

	}

	@Override
	public List<Product> getAllProduct() throws ProductException {
		Product product=null;
		List list;
		try {
			String query="select * from Productdetails";
			Object[] params=new Object[]{product.getId(),product.getName(),product.getQuantity(),product.getPrice()};
			list=JdbcTemplate.queryForList(query, new ProductMapper());
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			throw new ProductException(e.getMessage());
		}
		return list;
	}

}
