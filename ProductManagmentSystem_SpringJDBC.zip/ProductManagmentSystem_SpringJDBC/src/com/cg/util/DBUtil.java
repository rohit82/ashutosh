package com.cg.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DBUtil {

	public static EntityManager getEntityManager(){
		
	
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
	//get entity Manager
	EntityManager entityManager=factory.createEntityManager();
	return entityManager;
}
}