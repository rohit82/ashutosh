package com.cg.test;

import com.cg.entities.Product;
import com.cg.service.ProductServiceImpl;

public class Test {

	public static void main(String[] args) {
		/*ProductServiceImpl impl=new ProductServiceImpl();
		
		Product p1=new Product("HTCsmartwatch",10,2300);
		
		int id =impl.addPrduct(p1);
		System.out.println("Product Insert with id"+id);
		
		Product p2=impl.getProduct(id);
		System.out.println(p2);
		
		Product p4=new Product(id,"HTCsmartwatch",5,20000);
		impl.updateProduct(p4);
		System.out.println(impl.getProduct(id));
		
		
		impl.removeProduct(id);
		
		System.out.println(impl.getProduct(id));
		*/
	}
}
