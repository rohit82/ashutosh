drop table Productdetails
create table Productdetails(pid number primary key , pname varchar2(30),pquantity number(10),price number(8,2));
select * from Productdetails
delete Productdetails