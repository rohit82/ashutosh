create table User_Master(UserId varchar2(6),UserName varchar2(25),UserPassword varchar2(50),UserTypes varchar2(10));
select * from  USER_MASTER;

create table Department(Dept_ID number(6),Dept_Name varchar2(50) NOT NULL);
select * from DEPARTMENT

drop table employee
create table Employee(Emp_ID varchar2(6),Emp_First_Name varchar2(25) NOT NULL,Emp_Last_Name varchar2(25) 
NOT NULL,Emp_Date_of_Birth date,Emp_Date_of_Joining date,Emp_Dept_ID number(6),Emp_Grade varchar2(2) NOT NULL,
Emp_Designation varchar2(50),Emp_Basic number(10),Emp_Gender varchar2(1) NOT NULL,Emp_Marital_Status varchar2(10) 
NOT NULL,Emp_Home_Address varchar2(100),Emp_Contact_Num varchar2(15));
select * from EMPLOYEE
create sequence empSeq;

create table Grade_Master(Grade_Code varchar2(2),Description varchar2(10),Min_Salary number(10),Max_Salary number(10));
select * from Grade_Master