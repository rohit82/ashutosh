package com.emp.service;

import java.util.List;

import com.emp.bean.Employee;
import com.emp.exception.EmpoyeeException;

public interface IEmployeeService {

	public int addEmployee(Employee emp)throws EmpoyeeException;
	public Employee updateEmp(Employee e)throws EmpoyeeException;
	public List<Employee> showAll() throws EmpoyeeException;
}
