package com.emp.service;

import java.util.List;

import com.emp.Dao.EmployeeDaoImpl;
import com.emp.Dao.IEmployeeDao;
import com.emp.bean.Employee;
import com.emp.exception.EmpoyeeException;

public class EmployeeServiceImpl implements IEmployeeService {

	IEmployeeDao edeo=new EmployeeDaoImpl();
	@Override
	public int addEmployee(Employee emp) throws EmpoyeeException {
		// TODO Auto-generated method stub
		return edeo.addEmployee(emp);
	}

	@Override
	public Employee updateEmp(Employee e) throws EmpoyeeException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> showAll() throws EmpoyeeException {
		// TODO Auto-generated method stub
		return edeo.showAll();
	}

}
