package com.emp.exception;

public class EmpoyeeException  extends Exception{

	public EmpoyeeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmpoyeeException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public EmpoyeeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public EmpoyeeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public EmpoyeeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	
	

}
