package com.emp.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.sql.DataSource;


public class DBUtil {

	
	public static Connection getConnection() throws SQLException
	{
		
		InitialContext ic;
		DataSource ds;
		Connection con=null;
		try{
			if(con==null){
				
				
				 ic=new InitialContext();
				ds=(DataSource)ic.lookup("java:/jdbc/OracleDS");
				con=ds.getConnection();
				
				return con;
			}
			
		
		/*OracleDataSource ods=new OracleDataSource();
		
		ods.setUser("Labg103trg14");
		ods.setPassword("labg103oracle");
		ods.setDriverType("thin");
		ods.setNetworkProtocol("tcp");
		ods.setURL("jdbc:oracle:thin:@10.125.6.62:1521:orcl11g");*/
		
		
		}catch(Exception e){
			e.printStackTrace();
		}
		return con;
	}
}
