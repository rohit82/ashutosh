package com.emp.bean;

import java.sql.Date;

public class Employee {

	private int empId;

	private String empFname;

	private String empLname;

	private Date empDOB;

	private Date empDOJ;

	private int empDeptId;

	private String empGrade;

	private String Designation;

	private int empBasic;

	private String gender;

	private String MaritalStatus;

	private String HomeAddress;

	private long CNum;

	public Employee() {
		super();
	}

	public Employee(int empId, String empFname, String empLname, Date empDOB,
			Date empDOJ, int empDeptId, String empGrade, String designation,
			int empBasic, String gender, String maritalStatus,
			String homeAddress, long cNum) {
		super();
		this.empId = empId;
		this.empFname = empFname;
		this.empLname = empLname;
		this.empDOB = empDOB;
		this.empDOJ = empDOJ;
		this.empDeptId = empDeptId;
		this.empGrade = empGrade;
		Designation = designation;
		this.empBasic = empBasic;
		this.gender = gender;
		MaritalStatus = maritalStatus;
		HomeAddress = homeAddress;
		CNum = cNum;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpFname() {
		return empFname;
	}

	public void setEmpFname(String empFname) {
		this.empFname = empFname;
	}

	public String getEmpLname() {
		return empLname;
	}

	public void setEmpLname(String empLname) {
		this.empLname = empLname;
	}

	public Date getEmpDOB() {
		return empDOB;
	}

	public void setEmpDOB(Date empDOB) {
		this.empDOB = empDOB;
	}

	public Date getEmpDOJ() {
		return empDOJ;
	}

	public void setEmpDOJ(Date empDOJ) {
		this.empDOJ = empDOJ;
	}

	public int getEmpDeptId() {
		return empDeptId;
	}

	public void setEmpDeptId(int empDeptId) {
		this.empDeptId = empDeptId;
	}

	public String getEmpGrade() {
		return empGrade;
	}

	public void setEmpGrade(String empGrade) {
		this.empGrade = empGrade;
	}

	public String getDesignation() {
		return Designation;
	}

	public void setDesignation(String designation) {
		Designation = designation;
	}

	public int getEmpBasic() {
		return empBasic;
	}

	public void setEmpBasic(int empBasic) {
		this.empBasic = empBasic;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMaritalStatus() {
		return MaritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		MaritalStatus = maritalStatus;
	}

	public String getHomeAddress() {
		return HomeAddress;
	}

	public void setHomeAddress(String homeAddress) {
		HomeAddress = homeAddress;
	}

	public long getCNum() {
		return CNum;
	}

	public void setCNum(long cNum) {
		CNum = cNum;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empFname=" + empFname
				+ ", empLname=" + empLname + ", empDOB=" + empDOB + ", empDOJ="
				+ empDOJ + ", empDeptId=" + empDeptId + ", empGrade="
				+ empGrade + ", Designation=" + Designation + ", empBasic="
				+ empBasic + ", gender=" + gender + ", MaritalStatus="
				+ MaritalStatus + ", HomeAddress=" + HomeAddress + ", CNum="
				+ CNum + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + empId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (empId != other.empId)
			return false;
		return true;
	}
	
}
