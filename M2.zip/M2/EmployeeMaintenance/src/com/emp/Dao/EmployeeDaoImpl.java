package com.emp.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.emp.bean.Employee;
import com.emp.exception.EmpoyeeException;
import com.emp.util.DBUtil;

public class EmployeeDaoImpl implements IEmployeeDao {
	Connection conn;
	
	
	private int fatchemployeeid() throws EmpoyeeException{
		String sql="select empSeq.NEXTVAL From Dual";
		int pid;
		try{
			conn=DBUtil.getConnection();
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery(sql);
			rs.next();
			pid=rs.getInt(1);
			
		}
		catch(Exception e){
			throw new EmpoyeeException("problem in fatch data"+e.getMessage());
		}
		return pid;
	}
	
	@Override
	public int addEmployee(Employee emp) throws EmpoyeeException {
		
		String sql="insert into Employee values(?,?,?,?)";
		try{
			emp.setEmpId(fatchemployeeid());
			conn=DBUtil.getConnection();
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, emp.getEmpId());
			pst.setString(2, emp.getEmpFname());
			pst.setString(3, emp.getEmpLname());
			pst.setDate(4, emp.getEmpDOB());
			pst.setDate(5, emp.getEmpDOJ());
			pst.setInt(6, emp.getEmpDeptId());
			pst.setString(7, emp.getEmpGrade());
			pst.setString(8, emp.getDesignation());
			pst.setInt(9, emp.getEmpBasic());
			pst.setString(10, emp.getGender());
			pst.setString(11, emp.getMaritalStatus());
			pst.setString(12, emp.getHomeAddress());
			pst.setLong(13, emp.getCNum());
			pst.executeUpdate();
		}
			catch(SQLException e){
				throw new EmpoyeeException("problem in inserting data");
			}
			return emp.getEmpId();
		}
		

	@Override
	public Employee updateEmp(Employee e) throws EmpoyeeException {


		
		
	try {
		conn=DBUtil.getConnection();
			
			int id=e.getEmpId();
			String name=e.getEmpFname();
			String lname=e.getEmpLname();
			java.sql.Date dob=e.getEmpDOB();
			java.sql.Date doj=e.getEmpDOJ();
			int deptid=e.getEmpDeptId();
			String grade=e.getEmpGrade();
			String desig=e.getDesignation();
			int basic=e.getEmpBasic();
			String gender=e.getGender();
			String marit=e.getMaritalStatus();
			String homeadd=e.getHomeAddress();
			long cnum=e.getCNum();
			
			PreparedStatement pstm=conn.prepareStatement("update Employee set Emp_First_Name=?,Emp_Last_Name=?,Emp_Date_of_Birth=?,Emp_Date_of_Joining=?,Emp_Dept_ID=?,Emp_Grade=?,Emp_Designation=?,Emp_Basic=?,Emp_Gender=?,Emp_Marital_Status=?,Emp_Home_Address=?,Emp_Contact_Num=? where Emp_ID=?");
			
			pstm.setString(1, name);
			pstm.setString(2, lname);
			pstm.setDate(3, dob);
			pstm.setDate(4,doj);
			
			pstm.setInt(5,deptid);
			pstm.setString(6, grade);
			pstm.setString(7, desig);
			pstm.setInt(8, basic);
			pstm.setString(9, gender);
			pstm.setString(10, marit);
			pstm.setString(11, homeadd);
			pstm.setLong(12, cnum);
			pstm.setInt(13, id);
			pstm.execute();
			
		
		}
		  catch(SQLException q){
			 
				throw new EmpoyeeException(q.getMessage());
		  }
			//return employee;
	return e;
		}
		
	

	@Override
	public List<Employee> showAll() throws EmpoyeeException {
		
		String sql="select * from Employee";
		List<Employee>elist=new ArrayList<>();
		try{
			conn=DBUtil.getConnection();
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				Employee m=new Employee();
				m.setEmpId(rs.getInt(""));
				m.setEmpFname(rs.getString(""));
				m.setEmpLname(rs.getString(""));
				m.setEmpDOB(rs.getDate(""));
				m.setEmpDOJ(rs.getDate(""));
				m.setEmpDeptId(rs.getInt(""));
				m.setEmpGrade(rs.getString(""));
				m.setDesignation(rs.getString(""));
				m.setEmpBasic(rs.getInt(""));
				m.setGender(rs.getString(""));
				m.setMaritalStatus(rs.getString(""));
				m.setHomeAddress(rs.getString(""));
				m.setCNum(rs.getLong(""));
				elist.add(m);
			}
		}
		catch(SQLException e){
			throw new EmpoyeeException("problem in fatch data"+e.getMessage());
			
		}
		return elist;
				
				
			}
		
	}


